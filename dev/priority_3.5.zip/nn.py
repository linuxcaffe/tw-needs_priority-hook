#!/usr/bin/env python3
"""
nn.py - Priority hierarchy management for Taskwarrior (Needs Navigator)
Part of tw-priority-hook project

The hooks automatically maintain context.needs.read in need.rc.
This script shows the current state, adjusts configuration, and helps review/assign priorities.

Usage:
    nn                - Show priority report
    nn span <N>       - Set priority span (how many levels to show)
    nn update         - Manually recalculate and update context filter
    nn review         - Review and assign priorities to tasks
"""

import sys
import os
import subprocess
import json

# Configuration
HOOK_DIR = os.path.expanduser("~/.task/hooks/priority")
CONFIG_FILE = os.path.join(HOOK_DIR, "need.rc")

def get_config_value(key, default=None):
    """Read configuration value from need.rc"""
    try:
        with open(CONFIG_FILE, 'r') as f:
            for line in f:
                line = line.strip()
                if line.startswith(key + '='):
                    return line.split('=', 1)[1]
    except:
        pass
    return default

def set_config_value(key, value):
    """Set configuration value in need.rc"""
    lines = []
    found = False
    
    try:
        with open(CONFIG_FILE, 'r') as f:
            lines = f.readlines()
        
        with open(CONFIG_FILE, 'w') as f:
            for line in lines:
                if line.strip().startswith(key + '='):
                    f.write(f"{key}={value}\n")
                    found = True
                else:
                    f.write(line)
            
            if not found:
                f.write(f"\n{key}={value}\n")
        
        return True
    except Exception as e:
        print(f"Error updating config: {e}", file=sys.stderr)
        return False

def get_task_counts():
    """Get count of tasks at each priority level (ignores active context)"""
    counts = {'1': 0, '2': 0, '3': 0, '4': 0, '5': 0, '6': 0}
    
    try:
        for level in ['1', '2', '3', '4', '5', '6']:
            # Use rc.context=none to ignore active context
            result = subprocess.run(
                ['task', 'rc.context=none', f'priority:{level}', 'status:pending', 'count'],
                capture_output=True,
                text=True
            )
            if result.returncode == 0:
                counts[level] = int(result.stdout.strip() or 0)
    except Exception as e:
        print(f"Error getting task counts: {e}", file=sys.stderr)
    
    return counts

def get_lowest_priority():
    """Find the lowest priority level with pending tasks"""
    counts = get_task_counts()
    for level in ['1', '2', '3', '4', '5', '6']:
        if counts[level] > 0:
            return level
    return None

def build_context_filter(min_priority, span, lookahead, lookback):
    """Build context filter expression using pri.after"""
    min_pri = int(min_priority)
    max_pri = min(min_pri + int(span) - 1, 6)
    
    # Use pri.after:N to show priorities below N
    # pri.after:3 shows pri:1 and pri:2
    # So to show min_pri to max_pri, we use pri.after:(max_pri+1)
    if max_pri < 6:
        pri_expr = f"pri.after:{max_pri + 1}"
    else:
        # If max is 6, just show all priorities
        pri_expr = "pri.any:"
    
    # Add due/scheduled with user-specified time formats
    due_expr = f"( due.before:today+{lookahead} and due.after:today-{lookback} )"
    sched_expr = f"( scheduled.before:today+{lookahead} and sched.after:today-{lookback} )"
    
    return f"{pri_expr} or {due_expr} or {sched_expr}"

def update_context():
    """Manually recalculate and update context filter"""
    try:
        lowest = get_lowest_priority()
        if not lowest:
            print("No pending tasks, clearing context filter")
            filter_expr = ""
        else:
            span = get_config_value('priority.span', '2')
            lookahead = get_config_value('priority.lookahead', '2d')
            lookback = get_config_value('priority.lookback', '1w')
            filter_expr = build_context_filter(lowest, span, lookahead, lookback)
            print(f"Lowest priority: {lowest}")
            print(f"Filter: {filter_expr}")
        
        # Update need.rc
        lines = []
        found = False
        with open(CONFIG_FILE, 'r') as f:
            for line in f:
                if line.startswith('context.needs.read='):
                    lines.append(f'context.needs.read={filter_expr}\n')
                    found = True
                else:
                    lines.append(line)
        
        if not found:
            lines.append(f'\ncontext.needs.read={filter_expr}\n')
        
        with open(CONFIG_FILE, 'w') as f:
            f.writelines(lines)
        
        print("Context updated successfully")
        return True
        
    except Exception as e:
        print(f"Error updating context: {e}", file=sys.stderr)
        return False

def get_active_context():
    """Check if 'needs' context is currently active"""
    try:
        result = subprocess.run(
            ['task', '_get', 'rc.context'],
            capture_output=True,
            text=True
        )
        if result.returncode == 0:
            return result.stdout.strip() == 'needs'
    except:
        pass
    return False

def show_report():
    """Display priority pyramid report"""
    counts = get_task_counts()
    context_filter = get_config_value('context.needs.read', '')
    is_active = get_active_context()
    span = get_config_value('priority.span', '2')
    lookahead = get_config_value('priority.lookahead', '2d')
    lookback = get_config_value('priority.lookback', '1w')
    
    print()
    print("Priority Hierarchy Status")
    print("              ==========================================")
    
    # Determine which level is lowest (has tasks)
    lowest_level = None
    for level in ['1', '2', '3', '4', '5', '6']:
        if counts[level] > 0:
            lowest_level = level
            break
    
    # Calculate total tasks
    total_tasks = sum(counts.values())
    
    # Draw ASCII pyramid
    pyramid = [
        ('6', '/               Higher Goals               \\'),
        ('5', '/             Self Actualization             \\'),
        ('4', '/         Esteem, Respect & Recognition        \\'),
        ('3', '/       Love & Belonging, Friends & Family       \\'),
        ('2', '/   Personal safety, security, health, financial   \\'),
        ('1', '/      Physiological; Air, Water, Food & Shelter     \\')
    ]
    
    for level, label in pyramid:
        marker = ' |->' if level == lowest_level else '     '
        count = counts[level]
        print(f"{marker} {level}  {label}  ({count})")
    
    print("        ======================================================")
    print(f"        Config: span={span}, lookahead={lookahead}, lookback={lookback}              ({total_tasks})")
    print()
    
    print()
    print(f"Config: span={span}, lookahead={lookahead}, lookback={lookback}")
    print()
    
    # Show current context status
    if context_filter:
        print(f"Context filter (auto-updated by hooks):")
        print(f"  {context_filter}")
        print()
        if is_active:
            print("Status: Context 'needs' is ACTIVE")
            print("  Deactivate: task context none")
        else:
            print("Status: Context 'needs' is defined but NOT active")
            print("  Activate: task context needs")
    else:
        print("No pending tasks - context filter is empty")
        print("Add tasks to automatically update the filter")
    
    print()

def cmd_span(new_span):
    """Set priority span value"""
    try:
        span = int(new_span)
        if span < 1 or span > 6:
            raise ValueError
        
        if set_config_value('priority.span', str(span)):
            print(f"Priority span set to {span}")
            print("Updating context filter now...")
            # Trigger immediate context update
            if update_context():
                print("✓ Context filter updated")
            else:
                print("✗ Context update failed")
            return 0
        else:
            return 1
    except ValueError:
        print(f"Invalid span value: {new_span}", file=sys.stderr)
        return 1

def get_review_tasks():
    """
    Get tasks for review in priority order:
    1. H/M/L priorities (old format)
    2. Tasks with no priority
    3. Tasks with numeric priorities (1-6, lowest first)
    """
    tasks = []
    
    try:
        # Get all pending tasks as JSON
        result = subprocess.run(
            ['task', 'rc.context=none', 'status:pending', 'export'],
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            return []
        
        all_tasks = json.loads(result.stdout)
        
        # Separate into categories
        hml_tasks = []
        no_priority = []
        numeric_tasks = {str(i): [] for i in range(1, 7)}
        
        for task in all_tasks:
            pri = task.get('priority', '')
            
            if pri in ['H', 'M', 'L']:
                hml_tasks.append(task)
            elif not pri:
                no_priority.append(task)
            elif pri in ['1', '2', '3', '4', '5', '6']:
                numeric_tasks[pri].append(task)
        
        # Combine in order: H/M/L, no priority, then 1-6
        tasks.extend(hml_tasks)
        tasks.extend(no_priority)
        for level in ['1', '2', '3', '4', '5', '6']:
            tasks.extend(numeric_tasks[level])
        
        return tasks
        
    except Exception as e:
        print(f"Error getting tasks for review: {e}", file=sys.stderr)
        return []

def display_task_detail(task):
    """Display task with all relevant attributes"""
    print("\n" + "─" * 80)
    print(f"ID: {task.get('id', 'N/A')}")
    print(f"Description: {task.get('description', 'N/A')}")
    
    # Show current priority
    pri = task.get('priority', '(none)')
    if pri in ['H', 'M', 'L']:
        print(f"Priority: {pri} (OLD FORMAT - needs assignment)")
    else:
        print(f"Priority: {pri}")
    
    # Show other useful attributes
    if 'project' in task:
        print(f"Project: {task['project']}")
    if 'tags' in task and task['tags']:
        print(f"Tags: {', '.join(['+' + t for t in task['tags']])}")
    if 'due' in task:
        print(f"Due: {task['due']}")
    if 'scheduled' in task:
        print(f"Scheduled: {task['scheduled']}")
    if 'urgency' in task:
        print(f"Urgency: {task['urgency']:.2f}")
    
    print("─" * 80)

def cmd_review():
    """Interactive review and assignment of priorities"""
    tasks = get_review_tasks()
    
    if not tasks:
        print("No tasks need priority review!")
        return 0
    
    print(f"\nFound {len(tasks)} tasks to review")
    print("=" * 80)
    
    # Show priority pyramid first
    show_report()
    
    print("\nReview Mode")
    print("Enter priority (1-6), <enter> to skip, or 'q' to quit")
    print("=" * 80)
    
    reviewed = 0
    updated = 0
    skipped = 0
    
    for task in tasks:
        display_task_detail(task)
        
        # Prompt for priority
        while True:
            try:
                response = input("\nAssign priority [1-6, enter to skip, q to quit]: ").strip().lower()
                
                if response == 'q':
                    print(f"\nReviewed {reviewed} tasks, updated {updated}, skipped {skipped}")
                    return 0
                
                if response == '':
                    # Skip this task
                    print("⊘ Skipped")
                    skipped += 1
                    reviewed += 1
                    break
                
                if response in ['1', '2', '3', '4', '5', '6']:
                    # Update task priority
                    uuid = task['uuid']
                    result = subprocess.run(
                        ['task', uuid, 'modify', f'priority:{response}'],
                        capture_output=True,
                        text=True
                    )
                    
                    if result.returncode == 0:
                        print(f"✓ Set priority to {response}")
                        updated += 1
                        reviewed += 1
                        break
                    else:
                        print(f"✗ Error updating task: {result.stderr}")
                        break
                else:
                    print("Invalid input. Enter 1-6, press enter to skip, or 'q'")
            
            except (KeyboardInterrupt, EOFError):
                print(f"\n\nReviewed {reviewed} tasks, updated {updated}, skipped {skipped}")
                return 0
        
        # Clear screen and show pyramid before next task (if not done)
        if reviewed < len(tasks):
            # Clear screen
            subprocess.run(['clear'], shell=True)
            show_report()
            print("\nReview Mode")
            print("Enter priority (1-6), <enter> to skip, or 'q' to quit")
            print(f"Progress: {reviewed}/{len(tasks)}")
            print("=" * 80)
    
    print(f"\nAll tasks reviewed! Updated {updated} tasks, skipped {skipped}")
    return 0

def main():
    """Main entry point"""
    args = sys.argv[1:]
    
    if not args:
        show_report()
        return 0
    
    cmd = args[0].lower()
    
    if cmd == 'span':
        if len(args) < 2:
            print("Usage: nn span <N>", file=sys.stderr)
            return 1
        return cmd_span(args[1])
    elif cmd == 'update':
        return 0 if update_context() else 1
    elif cmd == 'review':
        return cmd_review()
    else:
        print(f"Unknown command: {cmd}", file=sys.stderr)
        print(__doc__)
        return 1

if __name__ == '__main__':
    sys.exit(main())
